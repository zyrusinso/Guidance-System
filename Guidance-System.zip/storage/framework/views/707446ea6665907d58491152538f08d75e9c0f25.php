

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('focusAdmin/vendor/datatables/css/jquery.dataTables.min.css')); ?>">
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Complains List</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-responsive-sm" id="myTable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Student Number</th>
                                <th>Student Full Name</th>
                                <th>Offense</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $incr = 1; ?>
                            <?php $__currentLoopData = $complain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($incr); ?></th>
                                    <td><?php echo e($data->stud_num); ?></td>
                                    <td><?php echo e($data->stud_name); ?></td>
                                    <td><?php echo e($data->offense_title); ?></td>
                                    <td><?php echo e(Carbon\Carbon::parse($data->created_at)->format('F j')); ?></td>
                                    <td>
                                        <a href="#" class="badge badge-outline-primary" data-toggle="modal"
                                            data-target=".bd-example-modal-lg">Info</a>
                                    </td>
                                </tr>
                                <?php $incr++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <!-- Large modal -->
    <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">Modal body text goes here.</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('focusAdmin/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script>
$(document).ready(function() {
    $('#myTable').DataTable();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guidance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamppp\htdocs\Guidance-System\resources\views/complain/index.blade.php ENDPATH**/ ?>