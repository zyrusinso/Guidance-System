

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('focusAdmin/vendor/datatables/css/jquery.dataTables.min.css')); ?>">
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Complainants</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-responsive-sm" id="myTable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Student Number</th>
                                <th>Student Full Name</th>
                                <th>Course</th>
                                <th>Offense</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th>1</th>
                                <td>123456789</td>
                                <td>Juan Dela Cruz</td>
                                <td>BSIT</td>
                                <td><span class="badge badge-primary">2nd</span>
                                </td>
                                <td>January 22</td>
                                <td>
                                    <a href="#" class="badge badge-outline-primary" data-toggle="modal"
                                        data-target=".bd-example-modal-lg">Info</a>
                                </td>
                            </tr>
                            <tr>
                                <th>2</th>
                                <td>987654321</td>
                                <td>John Doe</td>
                                <td>DICT</td>
                                <td><span class="badge badge-success">1st</span>
                                </td>
                                <td>January 30</td>
                                <td>
                                    <a href="#" class="badge badge-outline-primary">Info</a>
                                </td>
                            </tr>
                            <tr>
                                <th>3</th>
                                <td>132546798</td>
                                <td>John Cena</td>
                                <td>EDUC</td>
                                <td><span class="badge badge-danger">3rd</span>
                                </td>
                                <td>January 25</td>
                                <td>
                                    <a href="#" class="badge badge-outline-primary">Info</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <!-- Large modal -->
    <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">Modal body text goes here.</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('focusAdmin/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script>
$(document).ready(function() {
    $('#myTable').DataTable();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guidance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamppp\htdocs\Guidance-System\resources\views/complainants/index.blade.php ENDPATH**/ ?>