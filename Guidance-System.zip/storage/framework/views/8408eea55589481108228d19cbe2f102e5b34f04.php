<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>LOGIN</title>
    <!-- Favicon icon -->
    <link href="<?php echo e(asset('focusAdmin/css/style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('focusAdmin/vendor/sweetalert2/dist/sweetalert2.min.css')); ?>">
</head>



<body>
    <div class="row">
        <div class="col-lg-6 offset-3" style="margin-top: 190px;">
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger" style="max-width: 100%; color: white;">

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                •<?php echo e($error); ?><br />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <?php endif; ?>
            <div class="card shadow">
                <div class="card-body">
                    <h4 class="text-center mb-4">Sign in your account</h4>
                    <form method="POST" action="<?php echo e(route('login')); ?>" id="loginForm">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label><strong>Email</strong></label>
                            <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" autocomplete="email"
                                autofocus>

                        </div>
                        <div class="form-group">
                            <label><strong>Password</strong></label>
                            <input type="password" name="password" class="form-control">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-row d-flex justify-content-between mt-4 mb-2">
                            <div class="form-group">
                                <div class="form-check ml-2">
                                    <input class="form-check-input" name="remember" type="checkbox" id="basic_checkbox_1"
                                        <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="basic_checkbox_1">Remember
                                        me</label>
                                </div>
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary btn-block">Sign in</button>
                        </div>
                    </form>
                    <div class="new-account mt-3">
                        <p>Don't have an account? <a class="text-primary" href="<?php echo e(route('register')); ?>">Sign up</a></p>
                    </div>
                </div>
            </div>
        </div>

    </div>


    <!-- Required vendors -->
    <script src="<?php echo e(asset('focusAdmin/vendor/global/global.min.js')); ?>"></script>
    <script src="<?php echo e(asset('focusAdmin/js/quixnav-init.js')); ?>"></script>
    <script src="<?php echo e(asset('focusAdmin/js/custom.min.js')); ?>"></script>
    <script src="<?php echo e(asset('focusAdmin/vendor/sweetalert2/dist/sweetalert2.min.js')); ?>"></script>
</body>

</html><?php /**PATH E:\xamppp\htdocs\Guidance-System\resources\views/auth/login.blade.php ENDPATH**/ ?>