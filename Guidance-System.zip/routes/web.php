<?php

use Illuminate\Support\Facades\Route;

Auth::routes();

Route::middleware('auth')->group(function () {
    Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('/');
    Route::get('/home', function(){
        return redirect('/');
    });
});

Route::middleware(['auth', 'admin'])->group(function () {
    Route::resource('studentProfile', App\Http\Controllers\StudProfileController::class);

    Route::resource('complain', App\Http\Controllers\ComplainController::class);
});